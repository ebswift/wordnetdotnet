using TestTagger;

namespace WordsMatching
{
	/// <summary>
	/// Summary description for BrillTagger.
	/// </summary>
	public class BrillTagger
	{
		public BrillTagger()
		{
			//
			// TODO: Add constructor logic here
			//
		}


	}
}
